=== Sync products for Woocommerce | Webspark ===

Requires at least: 5.0.1
Tested up to: 5.6

== Установка ==

1. Загрузить файлы плагина в папку plugins
2. Активировать плагин

== Использование ==
1. После установки в боковом меню админки появится новый пункт "Product Sync". Зайти на єту страницу
2. Нажать кнопку "Sync product"